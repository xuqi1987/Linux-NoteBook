//
// Created by root on 19-7-23.
//

#include "V2xRvFilter.h"
namespace v2x {

bool V2xRvFilter::isDiscard(V2xMsg::ValuePtr &pHv, V2xMsg::ValuePtr &pRv)
{
    return false;
}

}

