//
// Created by root on 19-7-23.
//

#include "v2xApp/V2xSettting.h"
#include "Util/Util.h"

namespace v2x {


}
