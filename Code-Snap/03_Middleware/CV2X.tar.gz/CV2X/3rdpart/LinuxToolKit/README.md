详细介绍
https://xuqi1987.gitee.io/2019/07/01/C++常用工具类/
