#include <stdio.h>
#include <sys/types.h>
#include  "BasicSafetyMessage.h"
int main()
{

    return 0;
}